package com.my.demo01.entity;

import lombok.Data;

@Data
public class ProvinceAward {

  private int id;
  private String awardName;
  private String awardLevel;
  private String projectName;
  private String teamLeader;
  private String college;
  private String members;
  private String state;


}
