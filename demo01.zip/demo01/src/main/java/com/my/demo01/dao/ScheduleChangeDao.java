package com.my.demo01.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface ScheduleChangeDao {
}
