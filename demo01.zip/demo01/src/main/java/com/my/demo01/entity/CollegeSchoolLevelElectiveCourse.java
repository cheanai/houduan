package com.my.demo01.entity;

import lombok.Data;

@Data
public class CollegeSchoolLevelElectiveCourse {

  private int id;
  private String collegeName;
  private String courseName;
  private String courseCount;
  private String instructorName;
  private String state;


}
