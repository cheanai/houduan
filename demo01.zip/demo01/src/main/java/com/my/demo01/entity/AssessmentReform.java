package com.my.demo01.entity;

import lombok.Data;

@Data
public class AssessmentReform {

  private int id;
  private String projectName;
  private String college;
  private String reformContent;
  private String reformEffect;
  private String state;


}
