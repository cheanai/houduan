package com.my.demo01.service;

import org.springframework.stereotype.Service;

@Service
public class LeadershipClassObservationService {
}
